﻿namespace Stalky106
{
	public static class StalkConsoleCommands
	{

	}
}

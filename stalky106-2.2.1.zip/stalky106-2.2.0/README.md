# Stalky106
Ever wondered "how can SCP-106 get closer to its lore?" and wished that they just dissapeared at teslas, to make them easier to lose? Well, this plugin doesn't do that, but instead gets him closer to the lore by giving him the ability to stalk random people by placing a portal at their feet!

*Idea by ConnorTheCone and RogerFK*

# Discord
## Hop on [EXILED](https://github.com/galaxy119/EXILED) 's Discord if you want to get updates for this plugin! https://discord.gg/Avj4jeD

# How to use it

If you're playing as SCP-106, simply double click in the portal creation tool! It will give you further instructions on who you will stalk, if it's on cooldown...

![CREATE SINKHOLE](https://i.imgur.com/tQQWaGw.jpg)

# Translation info

You can change any line and even use the [UnityEngine's Rich Text Formatting](https://docs.unity3d.com/Manual/StyledText.html). If you want to get the default lines, just delete the values you changed in your `%appdata%\EXILED\Configs\<port>-config.yml` or `~/EXILED/Configs/<port>-config.yml` file.

# Extra info about SCP-106's lore

SCP-106 teleports to the victims he wants, according to its lore. He is also lured by loud sounds, which seem to be an easy victim for him. However, [SCP-106 delays himself 10-15 minutes after the femur breaker](http://www.scp-wiki.net/once-but-not-now), which makes the Femur Braker totally anti-lore. Although this remains completely out of his main idea, the point of this is to make him more friendly, fun and balanced for a multiplayer experience. With that in mind, him teleporting to random players means that it will be kept fair and that targeting one enemy is completely impossible... unless he is the last target alive. Which also made me think that I should have done an extra cooldown, but... uh don't ask me why I didn't do it, really. Will be an implemented feature in the future if I see interest in this plugin. Let me know in Discord by pinging me if you want any feature, or feel free to open an "issue" at the top of this page.
Another one, he can get to his own pocket dimensions and go through any exit to get out from it. That means you can either use the portal or just walk through a portal to leave the pocket dimension. This game is really weird so it just teleports you back to the pocket dimension, nobody will care about it but you can really fuck with people while doing it.
